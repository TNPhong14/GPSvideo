require('dotenv').config();
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const { createServer } = require('http');
const WebSocket = require('ws');
const path = require('path');
const winston = require('winston');
const fs = require('fs');

// Cấu hình logging
const logDir = 'logs';
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: path.join(logDir, 'error.log'), level: 'error' }),
    new winston.transports.File({ filename: path.join(logDir, 'combined.log') })
  ],
  exceptionHandlers: [
    new winston.transports.File({ filename: path.join(logDir, 'exceptions.log') })
  ],
  rejectionHandlers: [
    new winston.transports.File({ filename: path.join(logDir, 'rejections.log') })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.combine(
      winston.format.colorize(),
      winston.format.simple()
    )
  }));
}

// Khởi tạo ứng dụng
const app = express();
const server = createServer(app);
const wss = new WebSocket.Server({ server });

// Thiết lập API Key
const API_KEY = 'abcd1234';
app.set('api_key', API_KEY);

// Kết nối SQLite
const dbPath = './gps_data.db';
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    logger.error('Database connection error', { error: err.message, stack: err.stack });
    process.exit(1);
  }
  logger.info('Connected to SQLite database', { dbPath: dbPath });
});

// Tạo bảng và chỉ mục nếu chưa tồn tại
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS coordinates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      lat REAL NOT NULL,
      lon REAL NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `, (err) => {
    if (err) {
      logger.error('Error creating coordinates table', { error: err.message, stack: err.stack });
    } else {
      logger.info('Coordinates table ensured to exist.');
    }
  });

  db.run('CREATE INDEX IF NOT EXISTS idx_timestamp ON coordinates(timestamp)', (err) => {
    if (err) {
      logger.error('Error creating idx_timestamp index', { error: err.message, stack: err.stack });
    } else {
      logger.info('idx_timestamp index ensured to exist.');
    }
  });
});

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '/')));
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type, X-API-KEY');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Middleware kiểm tra API Key
const authenticate = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  const serverApiKey = req.app.get('api_key');

  if (apiKey === serverApiKey || (process.env.API_KEY && apiKey === process.env.API_KEY)) {
    return next();
  }

  logger.warn('Unauthorized access attempt', { path: req.path, ip: req.ip, userAgent: req.headers['user-agent'] });
  res.status(401).json({ error: 'Unauthorized: Invalid or missing X-API-KEY header' });
};

// WebSocket xử lý kết nối mới
wss.on('connection', (ws) => {
  logger.info('New WebSocket connection established.', { clientId: ws._socket.remoteAddress });
  ws.isAlive = true;

  ws.on('pong', () => { ws.isAlive = true; logger.debug('WebSocket pong received, client is alive.'); });
  ws.on('error', (error) => { logger.error('WebSocket error occurred', { error: error.message, stack: error.stack }); });
  ws.on('close', (code, reason) => { logger.info('WebSocket disconnected', { code: code, reason: reason.toString() }); });

  db.get(`
    SELECT lat, lon, timestamp 
    FROM coordinates 
    ORDER BY timestamp DESC 
    LIMIT 1
  `, (err, row) => {
    if (err) {
      logger.error('Error fetching initial data for new WebSocket client', { error: err.message, stack: err.stack });
    } else if (row) {
      ws.send(JSON.stringify({ type: 'init', data: row }));
      logger.info('Sent initial data to new WebSocket client.', { data: row });
    } else {
      logger.info('No initial data to send to new WebSocket client (database is empty).');
    }
  });
});

// Heartbeat kiểm tra kết nối WebSocket
setInterval(() => {
  wss.clients.forEach((ws) => {
    if (ws.isAlive === false) {
      logger.warn('WebSocket client not alive, terminating connection.', { clientId: ws._socket.remoteAddress });
      return ws.terminate();
    }
    ws.isAlive = false;
    ws.ping();
    logger.debug('WebSocket ping sent to client.');
  });
}, 30000);

// Endpoint: Thiết bị gửi GPS lên server
app.get('/update', (req, res) => {
  const { lat, lon } = req.query;

  if (!lat || !lon) {
    logger.warn('Missing coordinates in /update request', { query: req.query, ip: req.ip });
    return res.status(400).json({ error: 'Missing latitude or longitude' });
  }

  const latitude = parseFloat(lat);
  const longitude = parseFloat(lon);

  if (isNaN(latitude) || isNaN(longitude)) {
    logger.warn('Invalid coordinates format in /update request', { query: req.query, ip: req.ip });
    return res.status(400).json({ error: 'Invalid latitude or longitude format' });
  }

  db.run(`
    INSERT INTO coordinates (lat, lon) 
    VALUES (?, ?)`,
    [latitude, longitude],
    function(err) {
      if (err) {
        logger.error('Database insert error in /update', { error: err.message, stack: err.stack, lat, lon });
        return res.status(500).json({ error: 'Database error occurred during insertion' });
      }

      logger.info('New coordinate inserted', { lat: latitude, lon: longitude, rowId: this.lastID });

      db.run(`
        DELETE FROM coordinates 
        WHERE id NOT IN (
          SELECT id FROM coordinates 
          ORDER BY timestamp DESC 
          LIMIT 1000
        )`, (deleteErr) => {
          if (deleteErr) {
            logger.error('Error limiting database records', { error: deleteErr.message, stack: deleteErr.stack });
          } else {
            logger.debug('Database records limited to 1000.');
          }
      });

      const newData = {
        lat: latitude,
        lon: longitude,
        timestamp: new Date().toISOString()
      };

      broadcastUpdate(newData);
      res.json({ status: 'success', data: newData });
    }
  );
});

// Endpoint: Lấy lịch sử GPS (yêu cầu API key)
app.get('/coordinates', authenticate, (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 100, 1000);

  db.all(`
    SELECT lat, lon, timestamp 
    FROM coordinates 
    ORDER BY timestamp DESC 
    LIMIT ?`,
    [limit],
    (err, rows) => {
      if (err) {
        logger.error('Database query error for /coordinates', { error: err.message, stack: err.stack, limit });
        return res.status(500).json({ error: 'Database error occurred during query' });
      }

      res.json({ status: 'success', count: rows.length, data: rows });
    }
  );
});

// Endpoint: Xóa toàn bộ lịch sử GPS (yêu cầu API key)
app.post('/clear-history', authenticate, (req, res) => {
  db.run(`DELETE FROM coordinates`, function(err) {
    if (err) {
      logger.error('Database clear history error', { error: err.message, stack: err.stack });
      return res.status(500).json({ status: 'error', message: 'Failed to clear history' });
    }
    logger.info('All historical data cleared from database.');

    client.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ type: 'clear' }));
      }
    });

    res.json({ status: 'success', message: 'History cleared successfully' });
  });
});

// Gửi broadcast tới WebSocket
function broadcastUpdate(data) {
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: 'update', data: data }));
    }
  });
  logger.debug('Broadcasted update to all WebSocket clients.', { data: data });
}

// Khởi động server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`);
});